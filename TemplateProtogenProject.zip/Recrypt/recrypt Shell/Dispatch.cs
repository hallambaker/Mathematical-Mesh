﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Goedel.Debug;
using Goedel.Recrypt;
using Goedel.Recrypt.Client;

namespace Goedel.Recrypt.Shell {



    public partial class Shell {


        public Shell() {
            }


        /// <summary>
        /// Erase all test profiles
        /// </summary>
        /// <param name="Options">Command line parameters</param>
        public override void Reset(Reset Options) {

            }



        }
    }
