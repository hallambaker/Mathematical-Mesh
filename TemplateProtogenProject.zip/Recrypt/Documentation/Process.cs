﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Goedel.Tool.RFCDoc {
    class Process {

        //var TagCatalog = BridgeLib.Configure.GetTagCatalog(catalog);
        //var Import = new Import(TagCatalog);
        //Import.WordParse(inputfile, Document);

        
        }
    }
